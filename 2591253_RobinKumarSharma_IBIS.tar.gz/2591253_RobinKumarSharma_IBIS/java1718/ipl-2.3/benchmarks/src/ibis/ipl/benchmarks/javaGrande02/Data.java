package ibis.ipl.benchmarks.javaGrande02;

/* $Id: Data.java 11529 2009-11-18 15:53:11Z ceriel $ */

import java.io.Serializable;

public final class Data implements Serializable {

    private static final long serialVersionUID = 5187586557508679233L;

    public static final int PAYLOAD = 4*4;

    int i;
    int i1;
    int i2;
    int i3;

    public Data() {
    }
}





