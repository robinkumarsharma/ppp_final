This directory contains some benchmarks for Ibis. They are not very clean 
applications, and usually lack documentation. Still, they come in handy when
trying to determine the performance of Ibis.